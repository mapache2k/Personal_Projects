import datetime as dt
import pandas as pd
import numpy as np
import time as t

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

months_dict = {'January' : 1 , 'February' : 2 ,'March' : 3 ,'April' : 4 ,'May' : 5 ,'June' : 6 , 'All' : 0}

days_dict = {'Monday' : 1 ,'Tuesday' : 2 ,'Wednesday' : 3 ,'Thursday' : 4 ,'Friday' : 5 ,'Saturday' : 6 ,'Sunday' : 7 , 'All' : 0}

print('Hello! Let\'s explore some US bikeshare data!\n')



def get_filters():
    city = input('Choose a city from Chicago, New york city or Washington: ').lower()
    while city not in CITY_DATA:
        print('The spelling is not correct or you wrote a city that has no information available')
        restart = input('\nWould you like to try again? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
        city = input('Choose a city from Chicago, New york city or Washington: ').lower()

    month = input('Select the month to filter from January, February, March, April, May , June or type "all" for not filtering: ').title()
    while month not in months_dict:
        print('The spelling is not correct or you wrote a month that has no information available')
        restart = input('\nWould you like to try again? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
        month = input('Select the month to filter from January, February, March, April, May , June or type "all" for not filtering: ').title()

    day = input('Select the day of week from Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday or type "all" for not filtering: ').title()
    while day not in days_dict:
        print('The spelling is not correct or you wrote a month that has no information available')
        restart = input('\nWould you like to try again? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
        day = input('Select the day of week from Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday or type "all" for not filtering: ').title()

    print('-'*80)
    return city , month, day

def load_data(city,month,day):
    # creating an aux df to filter it later
    df = pd.read_csv(CITY_DATA.get(city))
    # first filtering by month
    if month != 'All':
        df = df[pd.to_datetime(df['Start Time']).dt.month == int(months_dict[month])]
    # second filtering by weekday
    if day != 'All':
        df = df[pd.to_datetime(df['Start Time']).dt.weekday == int(days_dict[day])]
    return df
# storing the data frame filtered by the user

def raw_data(df):
    while True:
        option = input('\nWould you like to see raw data (5 rows at a time) or statistics? Type yes for raw data and no for statistics\n')
        if option == 'yes':
            n=0
            print(df.iloc[int(n):int(n+5)])
            restart = input('\nWould you like to see 5 more rows? Enter yes or no.\n')
            while restart.lower() == 'yes':
                n+=5
                print(df.iloc[int(n):int(n+5)])
                restart = input('\nWould you like to see 5 more rows? Enter yes or no.\n')
            else:
                break
        else:
            return False

def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = t.time()
    # display the most common month
    freq_month = pd.to_datetime(df['Start Time']).dt.month.mode()[0]
    month_name = list(months_dict.keys())[list(months_dict.values()).index(freq_month)]
    print('The most common month is {}'.format(month_name))
    # display the most common day of week
    freq_day = pd.to_datetime(df['Start Time']).dt.weekday.mode()[0]
    day_name = list(days_dict.keys())[list(days_dict.values()).index(freq_day)]
    print('The most common day of the week is {}'.format(day_name))
    # display the most common start hour
    freq_hour = pd.to_datetime(df['Start Time']).dt.hour.mode()[0]
    print('The most common start hour is {}'.format(freq_hour))
    print("\n\nThis took %s seconds." % (t.time() - start_time))
    print('-'*80)

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = t.time()

    # display most commonly used start station
    freq_start = df['Start Station'].mode()[0]
    count_start = df['Start Station'].value_counts()
    max_start = count_start.max()
    print('The most used starting station is {} and has been used {} times'.format(freq_start,max_start))

    # display most commonly used end station

    freq_end = df['End Station'].mode()[0]
    count_end = df['End Station'].value_counts()
    max_end = count_end.max()
    print('The most used ending station is {} and has been used {} times'.format(freq_end,max_end))

    # display most frequent combination of start station and end station trip

    df['Route'] = df['Start Station']+" "+"to"+" "+df['End Station']
    freq_route = df['Route'].mode()[0]
    count_route = df['Route'].value_counts()
    max_route = count_route.max()
    print('The most frequent combination is from {} and has been used {} times'.format(freq_route,max_route))

    print("\n \nThis took %s seconds." % (t.time() - start_time))
    print('-'*80)

def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = t.time()

    # display total travel time

    total_time = df['Trip Duration'].sum()
    minu = total_time / 60
    hour = minu / 60

    print('The total trip duration is {} seconds or {} minutes or {} hours '.format(total_time, minu, hour.round(2)))

    # display mean travel time

    mean_time = df['Trip Duration'].mean()
    minu_mean = mean_time / 60

    print('The average travel time is {} second or {} minutes'.format(mean_time.round(2),minu_mean.round(2)))


    print("\nThis took %s seconds." % (t.time() - start_time))
    print('-'*80)

def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = t.time()
    # Display counts of user types

    if 'User Type' in df.columns:
        count_types = df['User Type'].value_counts()
        print('The users by type are as follows: \n\n'+count_types.to_string())
    else:
        print('No data of User Type available')
    print('\n')
    if 'Gender' in df.columns:
        count_gender = df['Gender'].value_counts()
        print('The users by gender are as follows: \n\n'+count_gender.to_string())
    else:
        print('No data of Gender available')

    print('\n')
    # Display earliest, most recent, and most common year of Birth

    if 'Birth Year' in df.columns:
        earliest = int(df['Birth Year'].min())
        most_recent = int(df['Birth Year'].max())
        most_common = df['Birth Year'].mode()
        print('The oldest user was born in {}, the youngest was born in {} and the users are mostly from {}'.format(earliest,most_recent,int(most_common[0])))
    else:
        print('No data of Birth available')

    print("\n\nThis took %s seconds." % (t.time() - start_time))
    print('-'*80)

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        raw_data(df)
        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
if __name__ == "__main__":
    main()
