https://stackoverrun.com/es/q/5217866  " for converting series to string " 

https://www.analyticslane.com/2019/06/21/seleccionar-filas-y-columnas-en-pandas-con-iloc-y-loc/ " for choosing certain rows in a DataFrame " 